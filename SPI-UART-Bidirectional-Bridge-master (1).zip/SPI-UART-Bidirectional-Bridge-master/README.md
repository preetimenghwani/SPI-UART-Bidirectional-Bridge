start => '1' to start communication

slave_width => '1' to send 8 bits

slave_width => '0' to send 16 bits

slave => "00" for MOSI

slave => "01" for MISO

once start is toggoled to '1', the code keep sending data given you provide inputs

